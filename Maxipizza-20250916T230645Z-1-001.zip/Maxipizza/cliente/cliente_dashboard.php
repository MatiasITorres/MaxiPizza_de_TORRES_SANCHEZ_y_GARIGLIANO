<?php
// cliente_dashboard.php
session_start();
require_once __DIR__ . '/../config.php';

// Validar sesión y rol
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'cliente') {
    header("Location: ./../index.php");
    exit();
}

$cliente_id = $_SESSION['usuario_id'];
$mensaje_confirmacion = '';
$mensaje_error = '';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Procesar nuevo pedido
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hacer_pedido'])) {
    $cantidades = $_POST['cantidades'] ?? [];
    $productos_pedidos = array_filter($cantidades, fn($q) => $q > 0);

    if (count($productos_pedidos) > 0) {
        $conn->begin_transaction();
        try {
            // Insertar el nuevo pedido en la tabla 'pedidos'
            $stmt = $conn->prepare("INSERT INTO pedidos (cliente_id, total, estado) VALUES (?, 0, 'pendiente')");
            if (!$stmt) { throw new Exception("Error al preparar la consulta para pedidos: " . $conn->error); }
            $stmt->bind_param("i", $cliente_id);
            $stmt->execute();
            $pedido_id = $conn->insert_id;
            $stmt->close();

            $total = 0;
            foreach ($productos_pedidos as $producto_id => $cantidad) {
                $stmt = $conn->prepare("SELECT precio FROM productos WHERE id = ?");
                if (!$stmt) { throw new Exception("Error al preparar la consulta para productos: " . $conn->error); }
                $stmt->bind_param("i", $producto_id);
                $stmt->execute();
                $stmt->bind_result($precio_unitario);
                $stmt->fetch();
                $stmt->close();

                if ($precio_unitario === null) { throw new Exception("Producto con ID " . htmlspecialchars($producto_id) . " no encontrado."); }

                $subtotal = $precio_unitario * $cantidad;
                $total += $subtotal;

                $stmt = $conn->prepare("INSERT INTO pedido_productos (pedido_id, producto_id, cantidad, precio_unitario, subtotal, estado) VALUES (?, ?, ?, ?, ?, 'pendiente')");
                if (!$stmt) { throw new Exception("Error al preparar la consulta para pedido_productos: " . $conn->error); }
                $stmt->bind_param("iiidd", $pedido_id, $producto_id, $cantidad, $precio_unitario, $subtotal);
                $stmt->execute();
                $stmt->close();
            }

            $stmt = $conn->prepare("UPDATE pedidos SET total = ? WHERE id = ?");
            if (!$stmt) { throw new Exception("Error al preparar la consulta para actualizar total: " . $conn->error); }
            $stmt->bind_param("di", $total, $pedido_id);
            $stmt->execute();
            $stmt->close();

            $conn->commit();
            $mensaje_confirmacion = "✅ ¡Tu pedido ha sido recibido con éxito! Total: $" . number_format($total, 2);
        } catch (Exception $e) {
            $conn->rollback();
            $mensaje_error = "❌ Error al procesar el pedido: " . $e->getMessage();
        }
    } else {
        $mensaje_error = "⚠️ Debes seleccionar al menos un producto para hacer un pedido.";
    }
}

// Cargar productos disponibles para el nuevo pedido
$productos_disponibles = [];
$prod_sql = "SELECT id, nombre, precio FROM productos WHERE disponible = 1 ORDER BY nombre ASC"; 
$prod_result = $conn->query($prod_sql);
if ($prod_result && $prod_result->num_rows > 0) {
    while ($row = $prod_result->fetch_assoc()) {
        $productos_disponibles[] = $row;
    }
}

// Traer pedidos del cliente
$pedidos_agrupados = [];
$sql = "SELECT 
            p.id AS pedido_id,
            p.fecha,
            p.total AS total_pedido,
            GROUP_CONCAT(CONCAT(pp.cantidad, 'x ', pr.nombre, ' ($', FORMAT(pp.precio_unitario, 2), ')') SEPARATOR '<br>') AS productos_detalle,
            p.estado AS estado_general_pedido
        FROM pedidos p
        JOIN pedido_productos pp ON p.id = pp.pedido_id
        JOIN productos pr ON pp.producto_id = pr.id
        WHERE p.cliente_id = ?
        GROUP BY p.id, p.fecha, p.total, p.estado
        ORDER BY p.fecha DESC";

$stmt = $conn->prepare($sql);
if ($stmt) {
    $stmt->bind_param("i", $cliente_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $pedidos_agrupados[] = $row;
        }
    } else {
        $mensaje_error .= " Error al cargar pedidos existentes: " . $conn->error;
    }
    $stmt->close();
} else {
    $mensaje_error .= " Error al preparar la consulta de pedidos: " . $conn->error;
}

$conn->close();

include 'header_cliente.php';

// Contenido principal de la página
?>
<div class="container">
    <div style="text-align: center;">
        <h1 style="margin-bottom: 5px;">¡Bienvenido a MaxiPizza!</h1>
        <p>Aquí puedes ver tus pedidos y realizar uno nuevo. ¡Saborea la diferencia!</p>
    </div>

    <?php if ($mensaje_confirmacion): ?>
        <div class="message success"><?= htmlspecialchars($mensaje_confirmacion) ?></div>
    <?php endif; ?>
    <?php if ($mensaje_error): ?>
        <div class="message error"><?= htmlspecialchars($mensaje_error) ?></div>
    <?php endif; ?>

    <hr>
    <div class="dashboard-section">
        <h2>Hacer un Nuevo Pedido</h2>
        <form method="POST" class="form-pedido">
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Cantidad</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($productos_disponibles)): ?>
                        <tr>
                            <td colspan="3" class="no-records">No hay productos disponibles para pedir en este momento.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($productos_disponibles as $producto): ?>
                            <tr>
                                <td><?= htmlspecialchars($producto['nombre']) ?></td>
                                <td>$<?= number_format($producto['precio'], 2) ?></td>
                                <td><input type="number" name="cantidades[<?= $producto['id'] ?>]" min="0" value="0"></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            <button type="submit" name="hacer_pedido">🍕 Confirmar Pedido</button>
        </form>
    </div>

    <hr>
    <div class="dashboard-section">
        <h2>Tus Pedidos Recientes</h2>
        <?php if (count($pedidos_agrupados) === 0): ?>
            <p class="no-records">Aún no has realizado ningún pedido. ¡Anímate a probar nuestras deliciosas pizzas!</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>N° Pedido</th>
                        <th>Fecha</th>
                        <th>Productos</th>
                        <th>Total</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidos_agrupados as $pedido): ?>
                        <tr>
                            <td>
                                <?php 
                                    $numero_pedido = ($pedido['pedido_id'] - 1) % 100 + 1;
                                    echo htmlspecialchars($numero_pedido);
                                ?>
                            </td>
                            <td><?= htmlspecialchars((new DateTime($pedido['fecha']))->format('d/m/Y H:i')) ?></td>
                            <td><?= $pedido['productos_detalle'] ?></td>
                            <td>$<?= htmlspecialchars(number_format($pedido['total_pedido'], 2)) ?></td>
                            <td class="estado-<?= htmlspecialchars($pedido['estado_general_pedido']) ?>">
                                <?= ucfirst(str_replace('_', ' ', $pedido['estado_general_pedido'])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>

<?php include 'footer_cliente.php'; ?>