<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Pedidos - MaxiPizza</title>
    <link rel="stylesheet" href="./../css/style.css"> 
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Lobster&display=swap" rel="stylesheet">
</head>
<body>
    <div class="container">
        <nav class="main-nav">
            <ul>
                <li><a href="cliente_dashboard.php">Mis Pedidos</a></li>
                <li><a href="?logout=true" class="logout-button">Cerrar Sesión</a></li>
            </ul>
        </nav>
    </div>
</body>
</html>