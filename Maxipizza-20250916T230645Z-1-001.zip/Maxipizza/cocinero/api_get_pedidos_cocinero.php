<?php
session_start();
require_once './../config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empleado') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acceso no autorizado.']);
    exit();
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

$query = "
    SELECT 
        p.id AS pedido_id, 
        c.nombre, 
        c.apellido,
        p.fecha, 
        p.estado
    FROM 
        pedidos p
    JOIN 
        clientes c ON p.cliente_id = c.id
    ORDER BY p.fecha DESC
";

$result = $conn->query($query);
$pedidos = [];

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $pedidos[] = [
            'pedido_id' => $row['pedido_id'],
            'cliente_nombre' => htmlspecialchars($row['nombre'] . ' ' . $row['apellido']),
            'fecha' => (new DateTime($row['fecha']))->format('d/m/Y H:i'),
            'estado' => $row['estado']
        ];
    }
}

echo json_encode($pedidos);

$conn->close();
?>