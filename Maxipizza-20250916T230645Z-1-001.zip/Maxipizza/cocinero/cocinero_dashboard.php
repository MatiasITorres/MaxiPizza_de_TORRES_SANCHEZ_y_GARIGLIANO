<?php
session_start();
require_once './../config.php'; // Tu archivo de conexión a la base de datos

// Seguridad: Verificar si el usuario ha iniciado sesión y tiene rol de cocinero
if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'cocinero') {
    if (empty($_SERVER['HTTP_X_REQUESTED_WITH'])) {
        header("Location: ./../index.php");
    } else {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'Acceso no autorizado.']);
    }
    exit();
}

// Establecer la conexión a la base de datos al principio
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Error de conexión a la base de datos.");
}

// --- LÓGICA DE ACTUALIZACIÓN DE ESTADO ---
// Esta sección ahora está preparada para responder a solicitudes AJAX con JSON.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_estado_producto') {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => 'Error desconocido.'];

    try {
        $pedido_producto_id = intval($_POST['pedido_producto_id']);
        $nuevo_estado = $_POST['estado'];

        // Validar que el estado sea uno de los permitidos para productos
        $estados_validos_producto = ['pendiente', 'en_preparacion', 'listo', 'cancelado'];
        if (!in_array($nuevo_estado, $estados_validos_producto)) {
            $response['message'] = "Estado de producto no válido.";
            echo json_encode($response);
            exit();
        }

        // Iniciar una transacción
        $conn->begin_transaction();

        // 1. Actualizar el estado del producto
        $stmt_producto = $conn->prepare("UPDATE pedido_productos SET estado = ? WHERE id = ?");
        $stmt_producto->bind_param("si", $nuevo_estado, $pedido_producto_id);
        if (!$stmt_producto->execute()) {
            throw new Exception("Error al actualizar el estado del producto.");
        }
        $stmt_producto->close();

        // 2. Comprobar y actualizar el estado del pedido principal
        // Obtener el ID del pedido principal
        $stmt_pedido = $conn->prepare("SELECT pedido_id FROM pedido_productos WHERE id = ?");
        $stmt_pedido->bind_param("i", $pedido_producto_id);
        $stmt_pedido->execute();
        $result_pedido = $stmt_pedido->get_result();
        $row_pedido = $result_pedido->fetch_assoc();
        $pedido_id = $row_pedido['pedido_id'];
        $stmt_pedido->close();

        // Verificar el estado de todos los productos del pedido
        $stmt_check = $conn->prepare("SELECT estado, COUNT(*) as count FROM pedido_productos WHERE pedido_id = ? GROUP BY estado");
        $stmt_check->bind_param("i", $pedido_id);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $estados_counts = [];
        $total_productos = 0;
        while ($row_count = $result_check->fetch_assoc()) {
            $estados_counts[$row_count['estado']] = $row_count['count'];
            $total_productos += $row_count['count'];
        }
        $stmt_check->close();

        // Determinar el nuevo estado del pedido principal
        $nuevo_estado_pedido = 'pendiente';
        if (isset($estados_counts['cancelado']) && $estados_counts['cancelado'] === $total_productos) {
            $nuevo_estado_pedido = 'cancelado';
        } elseif (isset($estados_counts['listo']) && $estados_counts['listo'] === $total_productos) {
            $nuevo_estado_pedido = 'listo';
        } elseif (isset($estados_counts['en_preparacion']) && $estados_counts['en_preparacion'] > 0) {
            $nuevo_estado_pedido = 'en_preparacion';
        }

        // Actualizar el estado del pedido principal si es necesario
        $stmt_update_pedido = $conn->prepare("UPDATE pedidos SET estado = ? WHERE id = ?");
        $stmt_update_pedido->bind_param("si", $nuevo_estado_pedido, $pedido_id);
        if (!$stmt_update_pedido->execute()) {
            throw new Exception("Error al actualizar el estado del pedido principal.");
        }
        $stmt_update_pedido->close();

        $conn->commit();
        $response['success'] = true;
        $response['message'] = "Estado de producto y pedido actualizado con éxito.";

    } catch (Exception $e) {
        $conn->rollback();
        $response['message'] = "Error en la operación: " . $e->getMessage();
        error_log("Error en update_estado_producto: " . $e->getMessage());
    } finally {
        $conn->close();
    }
    echo json_encode($response);
    exit();
}

// --- LÓGICA DE LECTURA DE DATOS PARA EL DASHBOARD ---
// Esta sección ahora responde a las peticiones GET desde el frontend
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'fetch_pedidos') {
    header('Content-Type: application/json');
    $response = ['success' => false, 'message' => 'Error al obtener los pedidos.', 'pedidos' => []];

    try {
        $sql = "
            SELECT 
                p.id as pedido_id, 
                p.fecha as fecha_creacion, 
                p.estado as estado_pedido,
                COALESCE(c.nombre, 'Cliente Anónimo') as cliente_nombre,
                pp.id as pedido_producto_id,
                pp.cantidad,
                pp.estado as estado_producto,
                pr.nombre as producto_nombre
            FROM pedidos p
            LEFT JOIN clientes c ON p.cliente_id = c.id
            JOIN pedido_productos pp ON p.id = pp.pedido_id
            JOIN productos pr ON pp.producto_id = pr.id
            WHERE p.estado IN ('pendiente', 'en_preparacion')
            ORDER BY p.fecha ASC;
        ";
        $result = $conn->query($sql);

        $pedidos_agrupados = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $pedido_id = $row['pedido_id'];

                if (!isset($pedidos_agrupados[$pedido_id])) {
                    $pedidos_agrupados[$pedido_id] = [
                        'pedido_id' => $pedido_id,
                        'fecha' => $row['fecha_creacion'],
                        'estado_pedido_principal' => $row['estado_pedido'],
                        'cliente_info' => $row['cliente_nombre'],
                        'items' => []
                    ];
                }
                $pedidos_agrupados[$pedido_id]['items'][] = [
                    'pedido_producto_id' => $row['pedido_producto_id'],
                    'producto_nombre' => $row['producto_nombre'],
                    'cantidad' => $row['cantidad'],
                    'estado_producto_individual' => $row['estado_producto']
                ];
            }
        }
        $response['success'] = true;
        $response['message'] = "Pedidos obtenidos exitosamente.";
        $response['pedidos'] = array_values($pedidos_agrupados);

    } catch (Exception $e) {
        $response['message'] = "Error en la base de datos: " . $e->getMessage();
        error_log("Error en fetch_pedidos: " . $e->getMessage());
    } finally {
        $conn->close();
    }
    echo json_encode($response['pedidos']); // Devolver solo el array de pedidos
    exit();
}

// Lógica para cerrar sesión
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: ./../index.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Cocinero | MaxiPizza</title>
    <style>
        /* Variables CSS (tomadas de admin_dashboard.php) */
        :root {
            --primary-color: #c0392b; /* Rojo pizza! */
            --secondary-color: #e67e22; /* Naranja vibrante (para encabezados) */
            --tertiary-color: #f39c12; /* Amarillo-naranja para modificar */
            --dark-text: #333; /* Texto oscuro */
            --light-bg: #f8f8f8; /* Fondo general claro */
            --white-bg: #ffffff;
            --light-border: #ddd; /* Bordes grises claros */
            --success-color: #27ae60;
            --error-color: #e74c3c;
            --info-color: #3498db;
            --grey-button: #7f8c8d; /* Gris para botones de cancelar/cerrar sesión */

            /* Estados de pedido */
            --status-pendiente: #f39c12; /* Amarillo-naranja para pendiente */
            --status-en_preparacion: #3498db; /* Azul para en preparación */
            --status-listo: #27ae60; /* Verde para listo */
            --status-entregado: #7f8c8d; /* Gris para entregado */
            --status-cancelado: #e74c3c; /* Rojo para cancelado */
        }

        body {
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--light-bg);
            color: var(--dark-text);
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        .container {
            width: 95%;
            max-width: 1200px;
            margin: 0 auto;
            background-color: var(--white-bg);
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            box-sizing: border-box;
        }

        h1 {
            font-family: 'Lobster', cursive;
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2.8em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
            padding-bottom: 10px;
            border-bottom: 2px solid var(--secondary-color);
            line-height: 1.2;
        }

        h2 {
            font-family: 'Lobster', cursive;
            color: var(--secondary-color);
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 2em;
            text-align: center;
            border-bottom: 2px solid var(--light-border);
            padding-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.08);
        }

        p {
            text-align: center;
            margin-bottom: 20px;
            color: var(--dark-text);
        }

        /* Status Messages */
        #status-message-container {
            margin-bottom: 20px;
            text-align: center;
            min-height: 25px; /* To prevent layout shift */
        }
        .message {
            padding: 12px 20px;
            border-radius: 8px;
            margin: 0 auto;
            width: fit-content;
            font-weight: 600;
            opacity: 0; /* Start hidden for fade-in */
            transform: translateY(-10px);
            animation: fadeInSlideUp 0.5s forwards;
        }
        .message.success {
            background-color: #e6ffe6; /* Light green */
            color: var(--success-color);
            border: 1px solid #d0f0d0;
        }
        .message.error {
            background-color: #ffe6e6; /* Light red */
            color: var(--error-color);
            border: 1px solid #f0d0d0;
        }
        @keyframes fadeInSlideUp {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Pedido Card */
        .pedido-card {
            background-color: var(--white-bg);
            border: 1px solid var(--light-border);
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 25px;
            padding: 25px;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .pedido-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(0, 0, 0, 0.12);
        }

        .pedido-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px dashed var(--light-border);
        }
        .pedido-header h2 {
            margin: 0;
            font-size: 1.8em;
            color: var(--primary-color); /* Pizza red for order number */
            border-bottom: none;
            padding-bottom: 0;
        }

        .pedido-info p {
            margin: 5px 0;
            text-align: left;
            font-size: 0.95em;
        }
        .pedido-info strong {
            color: var(--dark-text);
        }

        /* Item List */
        .item-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }
        .item-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #eee;
        }
        .item-list li:last-child {
            border-bottom: none;
        }

        .item-details {
            flex-grow: 1;
        }
        .item-details strong {
            font-size: 1.1em;
            color: var(--secondary-color); /* Orange for product name */
        }
        .item-details span {
            display: block;
            font-size: 0.9em;
            color: #666;
            margin-top: 3px;
        }

        /* Status Badges */
        .status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px; /* More rounded pill shape */
            font-size: 0.9em;
            font-weight: bold;
            color: white;
            text-transform: capitalize;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .status.pendiente { background-color: var(--status-pendiente); color: var(--dark-text); } /* Dark text for pending on light orange */
        .status.en_preparacion { background-color: var(--status-en_preparacion); }
        .status.listo { background-color: var(--status-listo); }
        .status.entregado { background-color: var(--status-entregado); }
        .status.cancelado { background-color: var(--status-cancelado); }


        /* Item Actions (Buttons) */
        .item-actions {
            display: flex;
            gap: 8px; /* Space between buttons */
            flex-wrap: wrap; /* Allow buttons to wrap */
            justify-content: flex-end;
        }
        .item-actions button {
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s ease, transform 0.1s ease, box-shadow 0.2s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            white-space: nowrap; /* Prevent text wrapping inside button */
        }
        .item-actions button:hover {
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }
        .item-actions button:active {
            transform: translateY(0);
        }

        .btn-preparing {
            background-color: var(--info-color); /* Blue */
            color: white;
        }
        .btn-preparing:hover {
            background-color: #2874a7; /* Darker blue */
        }

        .btn-ready {
            background-color: var(--success-color); /* Green */
            color: white;
        }
        .btn-ready:hover {
            background-color: #218838; /* Darker green */
        }

        .btn-reset {
            background-color: var(--grey-button); /* Grey */
            color: white;
        }
        .btn-reset:hover {
            background-color: #6c7a89; /* Darker grey */
        }

        .item-actions button:disabled {
            background-color: #ccc;
            cursor: not-allowed;
            opacity: 0.7;
            box-shadow: none;
            transform: none;
        }

        /* No orders message */
        .no-pedidos {
            text-align: center;
            padding: 50px 20px;
            background-color: var(--white-bg);
            border: 1px dashed var(--light-border);
            border-radius: 10px;
            color: #666;
            font-style: italic;
            margin-top: 20px;
        }
        .no-pedidos p {
            margin: 0;
            font-size: 1.2em;
        }

        /* Logout button */
        .logout-button { /* Changed from 'b' to 'logout-button' for clarity and consistency */
            background-color: var(--grey-button);
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            font-size: 1em;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: background-color 0.2s ease, transform 0.1s ease, box-shadow 0.2s ease;
            margin-top: 40px;
        }
        .logout-button:hover {
            background-color: #6c7a89;
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .container { padding: 25px; }
            h1 { font-size: 2.5em; }
            h2 { font-size: 1.8em; }
            .pedido-header h2 { font-size: 1.6em; }
        }

        @media (max-width: 768px) {
            body { padding: 15px; }
            .container { padding: 20px; }
            h1 { font-size: 2em; margin-bottom: 20px; }
            .pedido-card { padding: 20px; margin-bottom: 20px; }
            .item-list li { flex-direction: column; align-items: flex-start; gap: 10px; }
            .item-actions { width: 100%; justify-content: flex-start; }
            .item-actions button { width: auto; flex-grow: 1; } /* Buttons take available width */
            .logout-button { width: 100%; text-align: center; }
        }

        @media (max-width: 480px) {
            h1 { font-size: 1.8em; }
            .pedido-header h2 { font-size: 1.4em; }
            .item-details strong { font-size: 1em; }
            .status { font-size: 0.8em; padding: 5px 10px; }
            .item-actions button { font-size: 0.9em; padding: 8px 10px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Panel de Cocinero</h1>
        <p>Bienvenido, Cocinero <?php echo htmlspecialchars($_SESSION['usuario_email']); ?>. Aquí puedes ver y gestionar los pedidos.</p>

        <div id="status-message-container"></div>

        <div id="pedidos-container">
            </div>

        <a href="?logout=true" class="logout-button">Cerrar Sesión</a>
    </div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const container = document.getElementById('pedidos-container');
    const messageContainer = document.getElementById('status-message-container');

    // Función para renderizar los pedidos
    function renderPedidos(pedidos) {
        if (pedidos.length === 0) {
            container.innerHTML = `<div class="no-pedidos"><p>No hay pedidos pendientes o en preparación.</p></div>`;
            return;
        }

        let html = '';
        pedidos.forEach(pedido => {
            const estadoPrincipalText = pedido.estado_pedido_principal.replace('_', ' ');
            html += `
            <div class="pedido-card">
                <div class="pedido-header">
                    <h2>Pedido #${pedido.pedido_id}</h2>
                    <span class="status ${pedido.estado_pedido_principal}">${estadoPrincipalText}</span>
                </div>
                <div class="pedido-info">
                    <p><strong>Cliente:</strong> ${pedido.cliente_info}</p>
                    <p><strong>Fecha:</strong> ${pedido.fecha}</p>
                </div>
                <ul class="item-list">`;

            pedido.items.forEach(item => {
                const estadoIndividualText = item.estado_producto_individual.replace('_', ' ');
                const isItemDone = ['listo', 'entregado', 'cancelado'].includes(item.estado_producto_individual);

                html += `
                    <li>
                        <div class="item-details">
                            <strong>${item.producto_nombre}</strong> (x${item.cantidad})<br>
                            <span>Estado: <span class="status ${item.estado_producto_individual}">${estadoIndividualText}</span></span>
                        </div>
                        <div class="item-actions">
                            <button type="button" class="btn-preparing update-status-btn" data-id="${item.pedido_producto_id}" data-estado="en_preparacion" ${isItemDone ? 'disabled' : ''}>En Preparación</button>
                            <button type="button" class="btn-ready update-status-btn" data-id="${item.pedido_producto_id}" data-estado="listo" ${isItemDone ? 'disabled' : ''}>Marcar Listo</button>
                            <button type="button" class="btn-reset update-status-btn" data-id="${item.pedido_producto_id}" data-estado="pendiente" ${isItemDone ? 'disabled' : ''}>Restablecer</button>
                        </div>
                    </li>`;
            });
            html += `</ul></div>`;
        });
        container.innerHTML = html;
    }

    // Función para obtener los datos desde el API
    async function fetchPedidos() {
        try {
            // Se llama al mismo archivo con el parámetro 'action=fetch_pedidos'
            const response = await fetch('cocinero_dashboard.php?action=fetch_pedidos');
            const pedidos = await response.json();
            renderPedidos(pedidos);
        } catch (error) {
            console.error('Error al actualizar la lista de pedidos:', error);
            // Optionally, show a message to the user here too
        }
    }

    // Función para mostrar mensajes de estado
    function showStatusMessage(message, isSuccess) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${isSuccess ? 'success' : 'error'}`;
        messageDiv.textContent = message;
        messageContainer.innerHTML = ''; // Limpiar mensajes anteriores
        messageContainer.appendChild(messageDiv);
        setTimeout(() => messageDiv.remove(), 4000); // El mensaje desaparece después de 4 segundos
    }

    // --- NUEVO: Manejador de eventos para los botones de estado ---
    container.addEventListener('click', async function(event) {
        // Solo reacciona si se hizo clic en un botón para actualizar estado
        if (!event.target.classList.contains('update-status-btn')) {
            return;
        }

        const button = event.target;
        const pedidoProductoId = button.dataset.id;
        const nuevoEstado = button.dataset.estado;

        // Deshabilitar el botón para evitar clics múltiples
        button.disabled = true;

        // Prepara los datos para enviar
        const formData = new FormData();
        formData.append('action', 'update_estado_producto');
        formData.append('pedido_producto_id', pedidoProductoId);
        formData.append('estado', nuevoEstado);

        try {
            const response = await fetch('cocinero_dashboard.php', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();
            showStatusMessage(result.message, result.success);

            if (result.success) {
                // Si el cambio fue exitoso, volvemos a cargar la lista de pedidos
                // para reflejar todos los cambios (incluido el estado del pedido principal).
                fetchPedidos();
            } else {
                // Si falló, reactiva el botón
                button.disabled = false;
            }
        } catch (error) {
            console.error('Error al cambiar estado:', error);
            showStatusMessage('Error de conexión al intentar cambiar el estado.', false);
            button.disabled = false; // Reactiva el botón si hay un error
        }
    });

    // Carga inicial y actualización periódica
    fetchPedidos();
    setInterval(fetchPedidos, 5000);
});
</script>

</body>
</html>