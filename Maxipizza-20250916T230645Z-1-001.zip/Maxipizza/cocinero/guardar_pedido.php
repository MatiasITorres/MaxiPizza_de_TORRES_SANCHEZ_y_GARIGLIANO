<?php
session_start();
require_once './../config.php';

header('Content-Type: application/json');

if (!isset($_SESSION['usuario_id']) || $_SESSION['usuario_rol'] !== 'empleado') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Acceso no autorizado.']);
    exit();
}

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos.']);
    exit();
}

$input = json_decode(file_get_contents('php://input'), true);
if (!isset($input['cliente_id']) || !isset($input['items']) || empty($input['items'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Datos de pedido incompletos.']);
    $conn->close();
    exit();
}

$cliente_id = intval($input['cliente_id']);
$items = $input['items'];

$conn->begin_transaction();

try {
    // Calcular el total del pedido
    $total = 0;
    foreach ($items as $item) {
        $stmt_precio = $conn->prepare("SELECT precio FROM productos WHERE id = ?");
        $stmt_precio->bind_param("i", $item['producto_id']);
        $stmt_precio->execute();
        $result_precio = $stmt_precio->get_result();
        if ($row = $result_precio->fetch_assoc()) {
            $total += $row['precio'] * $item['cantidad'];
        }
        $stmt_precio->close();
    }

    // Insertar el nuevo pedido en la tabla `pedidos`
    $stmt_pedido = $conn->prepare("INSERT INTO pedidos (cliente_id, fecha, total, estado) VALUES (?, NOW(), ?, 'pendiente')");
    $stmt_pedido->bind_param("id", $cliente_id, $total);
    if (!$stmt_pedido->execute()) {
        throw new Exception("Error al insertar el pedido principal.");
    }
    $pedido_id = $conn->insert_id;
    $stmt_pedido->close();

    // Insertar cada producto del pedido en la tabla `pedido_productos`
    $stmt_producto = $conn->prepare("INSERT INTO pedido_productos (pedido_id, producto_id, cantidad, estado) VALUES (?, ?, ?, 'pendiente')");
    foreach ($items as $item) {
        $stmt_producto->bind_param("iii", $pedido_id, $item['producto_id'], $item['cantidad']);
        if (!$stmt_producto->execute()) {
            throw new Exception("Error al insertar un producto del pedido.");
        }
    }
    $stmt_producto->close();

    $conn->commit();
    echo json_encode(['success' => true, 'message' => 'Pedido guardado con éxito!', 'pedido_id' => $pedido_id]);

} catch (Exception $e) {
    $conn->rollback();
    http_response_code(500);
    error_log("Error al guardar pedido: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error en la base de datos: ' . $e->getMessage()]);
}

$conn->close();
?>