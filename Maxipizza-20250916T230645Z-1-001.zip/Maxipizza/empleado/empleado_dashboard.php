<?php
session_start();
// NOTA: Asegúrate de que la ruta a tu archivo de conexión sea correcta.
require_once './../config.php';

// Establecer la conexión a la base de datos al principio
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Redirigir si el usuario no está logeado o no es un empleado
if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'empleado') {
    header("Location: ./../index.php");
    exit();
}

// --- SECCIÓN PARA OBTENER CATEGORÍAS ---
$categorias_disponibles = [];
try {
    $sql_categorias = "SELECT id, nombre FROM categorias_productos ORDER BY nombre ASC";
    $result_categorias = $conn->query($sql_categorias);

    if ($result_categorias && $result_categorias->num_rows > 0) {
        while ($row = $result_categorias->fetch_assoc()) {
            $categorias_disponibles[] = $row;
        }
    }
} catch (Exception $e) {
    error_log("Error al obtener categorías: " . $e->getMessage());
    $categorias_disponibles = [];
}

// --- SECCIÓN PARA MOSTRAR PRODUCTOS/COMBOS DISPONIBLES AGRUPADOS POR CATEGORÍA ---
$productos_por_categoria = [];
$productos_disponibles_raw = []; // Keep a flat list for JS if needed later, though not directly used for display here
try {
    // Modificar la consulta para incluir el nombre de la categoría
    $sql_productos = "SELECT p.id, p.nombre, p.precio, c.nombre AS categoria_nombre
                      FROM productos p
                      LEFT JOIN categorias_productos c ON p.categoria_id = c.id
                      ORDER BY c.nombre ASC, p.nombre ASC"; // Order by category then product name
    $result_productos = $conn->query($sql_productos);

    if ($result_productos && $result_productos->num_rows > 0) {
        while ($row = $result_productos->fetch_assoc()) {
            $productos_disponibles_raw[] = $row; // Store raw data

            $categoria_nombre = $row['categoria_nombre'] ?: 'Sin Categoría'; // Group uncategorized products
            if (!isset($productos_por_categoria[$categoria_nombre])) {
                $productos_por_categoria[$categoria_nombre] = [];
            }
            $productos_por_categoria[$categoria_nombre][] = $row;
        }
    }
} catch (Exception $e) {
    error_log("Error al obtener productos: " . $e->getMessage());
    $productos_por_categoria = [];
    $productos_disponibles_raw = [];
}

// --- SECCIÓN PARA OBTENER CLIENTES REGISTRADOS ---
$clientes_disponibles = [];
try {
    // CORRECCIÓN: La consulta debe ser a la tabla 'clientes' para coincidir con la lógica del sistema
    $sql_clientes = "SELECT id, nombre, email, telefono, ubicacion FROM clientes ORDER BY email ASC";
    $result_clientes = $conn->query($sql_clientes);
    if ($result_clientes) {
        while ($row = $result_clientes->fetch_assoc()) {
            $clientes_disponibles[] = $row;
        }
    }
} catch (Exception $e) {
    error_log("Error al obtener clientes: " . $e->getMessage());
    $clientes_disponibles = [];
}

// --- OBTENER PEDIDOS PARA GESTIONAR ---
$pedidos_a_gestionar = [];
try {
    $sql_pedidos = "SELECT p.id, p.cliente_id, c.nombre AS cliente_nombre, c.email AS cliente_email,
                           c.nombre, c.ubicacion, c.telefono,
                           p.fecha, p.total, p.estado
                     FROM pedidos p
                     LEFT JOIN clientes c ON p.cliente_id = c.id
                     ORDER BY p.fecha DESC";

    $result_pedidos = $conn->query($sql_pedidos);

    if ($result_pedidos && $result_pedidos->num_rows > 0) {
        while ($row = $result_pedidos->fetch_assoc()) {
            $pedidos_a_gestionar[] = $row;
        }
    }
} catch (Exception $e) {
    error_log("Error al obtener pedidos para gestión: " . $e->getMessage());
    $pedidos_a_gestionar = [];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Empleado | MaxiPizza</title>
    <link rel="stylesheet" href="./../css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Lobster&display=swap" rel="stylesheet">
    <style>
        /* Variables CSS (tomadas de admin_dashboard.php) */
        :root {
            --primary-color: #c0392b; /* Rojo pizza! */
            --secondary-color: #e67e22; /* Naranja vibrante (para encabezados) */
            --tertiary-color: #f39c12; /* Amarillo-naranja para modificar */
            --dark-text: #333; /* Texto oscuro */
            --light-bg: #f8f8f8; /* Fondo general claro */
            --white-bg: #ffffff;
            --light-border: #ddd; /* Bordes grises claros */
            --success-color: #27ae60;
            --error-color: #e74c3c;
            --info-color: #3498db;
            --grey-button: #7f8c8d; /* Gris para botones de cancelar/cerrar sesión */

            /* Estados de pedido */
            --status-pendiente: #f39c12; /* Naranja para pendiente */
            --status-en_preparacion: #3498db; /* Azul para en preparación */
            --status-listo: #27ae60; /* Verde para listo */
            --status-entregado: #7f8c8d; /* Gris para entregado */
            --status-cancelado: #e74c3c; /* Rojo para cancelado */
        }

        /* General Body & Container Styles */
        body {
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--light-bg);
            color: var(--dark-text);
            line-height: 1.6;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        h1 {
            font-family: 'Lobster', cursive;
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2.8em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
            padding-bottom: 10px;
            border-bottom: 2px solid var(--secondary-color);
            line-height: 1.2;
            width: 95%; /* Adjust width for consistency */
            max-width: 1300px;
        }

        h2, h3 {
            font-family: 'Lobster', cursive;
            color: var(--secondary-color);
            margin-top: 0;
            margin-bottom: 20px;
            font-size: 2em;
            text-align: center;
            border-bottom: 2px solid var(--light-border);
            padding-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.08);
        }

        a {
            color: var(--dark-text); /* Changed link color for better contrast */
            text-decoration: none;
            padding: 10px 20px;
            background-color: var(--light-border); /* Changed background for consistency */
            border-radius: 5px;
            display: inline-block;
            margin-top: 20px;
            font-weight: 600;
            transition: background-color 0.2s ease, color 0.2s ease;
        }
        a:hover {
            text-decoration: none;
            background-color: var(--grey-button); /* Hover color from admin_dashboard */
            color: white; /* Text color on hover */
        }

        .main-content-wrapper {
            display: flex;
            gap: 30px; /* Increased gap */
            margin-top: 20px;
            flex-wrap: wrap;
            width: 95%; /* Make it take full width of container */
            max-width: 1300px; /* Match max width of admin */
        }

        .products-section, .order-summary-section, .manage-orders-section {
            background-color: var(--white-bg);
            border: 1px solid var(--light-border);
            border-radius: 10px; /* More rounded corners */
            padding: 30px; /* Increased padding */
            box-shadow: 0 4px 15px rgba(0,0,0,0.1); /* Stronger shadow */
            margin-bottom: 20px;
            box-sizing: border-box; /* Ensure padding is included in width */
        }
        .products-section { flex: 2; min-width: 350px; } /* Ensure it's not too narrow */
        .order-summary-section { flex: 1; min-width: 350px; }
        .manage-orders-section { flex-basis: 100%; margin-top: 30px; }

        /* Styles for collapsible categories */
        .category-details {
            margin-bottom: 15px;
            border: 1px solid var(--light-border);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }

        .category-summary {
            background-color: var(--secondary-color);
            color: white;
            padding: 15px 20px;
            cursor: pointer;
            font-weight: 700;
            font-size: 1.2em;
            display: block;
            position: relative;
            user-select: none; /* Prevent text selection on click */
            transition: background-color 0.2s ease;
        }
        .category-summary:hover {
            background-color: #d35400; /* Darker orange on hover */
        }

        .category-summary::marker, /* Hide default marker in some browsers */
        .category-summary::-webkit-details-marker { /* Hide default marker in WebKit */
            display: none;
            content: "";
        }

        .category-summary::before {
            content: '►'; /* Custom arrow for closed state */
            position: absolute;
            left: 15px;
            font-size: 0.8em;
            transition: transform 0.2s ease;
        }

        .category-details[open] > .category-summary::before {
            content: '▼'; /* Custom arrow for open state */
            transform: rotate(0deg); /* Reset rotation for open state */
        }

        .category-content {
            padding: 15px 20px;
            background-color: #fefefe;
        }

        .product-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0; /* Increased padding */
            border-bottom: 1px solid var(--light-border); /* Solid border */
            margin-bottom: 10px; /* Space between items */
        }
        .product-item:last-child {
            border-bottom: none; /* No border for the last item */
        }

        .product-info { flex-grow: 1; margin-right: 15px; }
        .product-name {
            font-weight: 600;
            color: var(--primary-color); /* Highlight product name */
            font-size: 1.1em;
        }
        .product-price-value {
            font-weight: bold;
            color: var(--secondary-color); /* Highlight price */
        }

        .product-actions input[type="number"] {
            width: 70px; /* Wider input */
            padding: 8px; /* More padding */
            border: 1px solid #ccc;
            border-radius: 5px; /* Slightly more rounded */
            text-align: center;
            font-size: 1em;
        }
        .product-actions button {
            background-color: var(--success-color); /* Green add button */
            color: white;
            border: none;
            padding: 10px 15px; /* Larger padding */
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s ease, transform 0.1s ease, box-shadow 0.2s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .product-actions button:hover {
            background-color: #218838; /* Darker green on hover */
            transform: translateY(-1px);
        }

        .customer-info-fields {
            margin-bottom: 25px; /* More space */
            padding-bottom: 20px;
            border-bottom: 1px solid var(--light-border);
        }
        .customer-info-fields label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--dark-text);
            font-size: 1.05em;
        }
        .customer-info-fields input[type="text"],
        #existing_cliente_id {
            width: calc(100% - 24px); /* Match admin input width calc */
            padding: 12px; /* More padding */
            margin-bottom: 18px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 1em;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        .customer-info-fields input[type="text"]:focus,
        #existing_cliente_id:focus {
            border-color: var(--secondary-color);
            box-shadow: 0 0 8px rgba(230, 126, 34, 0.2);
            outline: none;
        }

        #current-order-list {
            list-style: none;
            padding: 0;
            margin-top: 15px;
        }
        #current-order-list li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px dotted #eee;
        }
        #current-order-list li:last-child {
            border-bottom: none;
        }

        #current-order-total {
            font-weight: bold;
            text-align: right;
            margin-top: 15px;
            padding-top: 10px;
            border-top: 2px solid var(--secondary-color); /* Thicker border with accent color */
            font-size: 1.3em; /* Larger font */
            color: var(--primary-color);
        }
        .order-buttons {
            display: flex;
            justify-content: flex-end; /* Align buttons to the right */
            gap: 10px;
            margin-top: 20px;
        }
        .order-buttons button {
            background-color: var(--info-color); /* Info color for place order */
            color: white;
            border: none;
            padding: 12px 25px; /* Larger buttons */
            border-radius: 5px;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.2s ease, transform 0.1s ease, box-shadow 0.2s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        .order-buttons button:hover {
            background-color: #2874a7; /* Darker blue on hover */
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }
        .order-buttons button.clear {
            background-color: var(--grey-button); /* Grey for clear */
        }
        .order-buttons button.clear:hover {
            background-color: #6c7a89; /* Darker grey on hover */
        }

        .status-message {
            padding: 15px; /* More padding */
            border-radius: 8px; /* More rounded */
            margin-bottom: 20px;
            text-align: center;
            font-weight: 600; /* Bolder text */
            display: none;
            border: 1px solid transparent;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }
        .status-message.success { background-color: #e6ffe6; color: var(--success-color); border-color: #d0f0d0; }
        .status-message.error { background-color: #ffe6e6; color: var(--error-color); border-color: #f0d0d0; }

        .order-table {
            width: 100%;
            border-collapse: separate; /* Changed to separate */
            border-spacing: 0;
            margin-top: 20px; /* More space */
            border-radius: 8px;
            overflow: hidden; /* For rounded corners */
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
            background-color: var(--white-bg);
            border: 1px solid var(--light-border);
        }
        .order-table th, .order-table td {
            border-bottom: 1px solid var(--light-border); /* Consistent border */
            padding: 12px 15px; /* More padding */
            text-align: left;
            vertical-align: middle; /* Align middle */
            font-size: 1em;
        }
        .order-table th {
            background-color: var(--secondary-color);
            color: white;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .order-table tr:nth-child(even) { background-color: #f9f9f9; }
        .order-table tr:hover { background-color: #f5f5f5; }

        .order-actions {
            display: flex; /* Use flex for actions */
            gap: 8px;
            flex-wrap: wrap; /* Allow wrapping */
            justify-content: flex-start; /* Align to start */
        }
        .order-actions button, .order-actions select {
            padding: 8px 12px; /* Consistent button padding */
            border-radius: 5px;
            border: 1px solid #ccc;
            cursor: pointer;
            margin-right: 0; /* Remove default margin */
            font-weight: 600;
            transition: background-color 0.2s ease, transform 0.1s ease;
        }
        .order-actions select {
            background-color: #fefefe;
            border-color: var(--light-border);
            color: var(--dark-text);
        }
        .order-actions button {
            background-color: var(--tertiary-color); /* Orange for update */
            color: var(--dark-text); /* Dark text for contrast */
            border: none;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .order-actions button:hover {
            background-color: #e67e22; /* Darker orange on hover */
            color: white; /* White text on hover */
            transform: translateY(-1px);
        }

        .status-badge {
            display: inline-block;
            padding: 6px 10px;
            border-radius: 5px;
            font-size: 0.9em;
            font-weight: bold;
            color: white;
            text-transform: capitalize; /* Capitalize status */
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        .status-pendiente { background-color: var(--status-pendiente); color: var(--dark-text); } /* Text dark for pending */
        .status-en_preparacion { background-color: var(--status-en_preparacion); }
        .status-listo { background-color: var(--status-listo); }
        .status-entregado { background-color: var(--status-entregado); }
        .status-cancelado { background-color: var(--status-cancelado); }

        /* Logout button style */
        .logout-button-container {
            width: 100%;
            max-width: 1300px;
            text-align: center;
            margin-top: 40px;
        }
        .logout-button {
            background-color: var(--grey-button);
            color: white;
            padding: 12px 25px;
            border-radius: 5px;
            font-size: 1em;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            transition: background-color 0.2s ease, transform 0.1s ease, box-shadow 0.2s ease;
        }
        .logout-button:hover {
            background-color: #6c7a89;
            transform: translateY(-1px);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            .main-content-wrapper { gap: 25px; }
            h1 { font-size: 2.5em; }
            h2, h3 { font-size: 1.8em; }
            th, td { padding: 12px 15px; }
        }

        @media (max-width: 768px) {
            body { padding: 15px; }
            h1 { font-size: 2em; margin-bottom: 20px; }
            .main-content-wrapper { flex-direction: column; gap: 20px; }
            .products-section, .order-summary-section, .manage-orders-section { padding: 25px; }
            h2, h3 { font-size: 1.5em; margin-bottom: 15px; }
            .customer-info-fields input[type="text"],
            #existing_cliente_id { width: 100%; padding: 10px; margin-bottom: 15px; }
            .order-buttons { flex-direction: column; gap: 10px; }
            .order-buttons button { width: 100%; }
            .product-actions { display: flex; flex-direction: column; gap: 10px; align-items: flex-end;}
            .product-actions input[type="number"] { width: 100px; } /* Adjust width for better fit */
            .order-actions { flex-direction: column; gap: 5px; }
            .order-actions button, .order-actions select { width: 100%; }
        }
        @media (max-width: 480px) {
            h1 { font-size: 1.8em; }
            h2, h3 { font-size: 1.3em; }
            th, td { padding: 10px; font-size: 0.9em; }
            .status-badge { padding: 5px 8px; font-size: 0.8em; }
            .logout-button-container { margin-top: 30px; }
            .logout-button { width: 100%; }
        }
    </style>
</head>
<body>
    <h1>Bienvenido, Empleado <?php echo htmlspecialchars($_SESSION['usuario_email']); ?></h1>
    <p>Este es el panel para el personal de ventas y atención al cliente.</p>

    <div class="status-message" id="php-message"></div>

    <div class="main-content-wrapper">
        <div class="products-section">
            <h2>Productos/Combos Disponibles</h2>
            <?php if (empty($productos_por_categoria)): ?>
                <p class="no-data">No hay productos disponibles.</p>
            <?php else: ?>
                <?php foreach ($productos_por_categoria as $categoria_nombre => $productos): ?>
                    <details class="category-details">
                        <summary class="category-summary"><?php echo htmlspecialchars($categoria_nombre); ?></summary>
                        <div class="category-content">
                            <?php foreach ($productos as $producto): ?>
                                <div class="product-item">
                                    <div class="product-info">
                                        <span class="product-name" data-id="<?php echo htmlspecialchars($producto['id']); ?>"><?php echo htmlspecialchars($producto['nombre']); ?></span>
                                        <br><small>Precio: $<span class="product-price-value"><?php echo htmlspecialchars($producto['precio']); ?></span></small>
                                    </div>
                                    <div class="product-actions">
                                        <input type="number" class="quantity-input" value="1" min="1">
                                        <button class="add-to-order-btn">Añadir al Pedido</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </details>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>

        <div class="order-summary-section">
            <h2>Crear Pedido Nuevo</h2>
            <div class="customer-info-fields">
                <h3>Datos del Cliente</h3>
                <div class="form-group">
                    <label for="existing_cliente_id">Seleccionar Cliente:</label>
                    <select name="existing_cliente_id" id="existing_cliente_id">
                        <option value="0">-- Cliente no registrado --</option>
                        <?php foreach ($clientes_disponibles as $cliente): ?>
                            <option value="<?php echo htmlspecialchars($cliente['id']); ?>">
                                <?php echo htmlspecialchars($cliente['email'] . ' - ' . $cliente['nombre']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div id="new-client-fields" class="client-fields" style="display: none;">
                    <label for="new_client_name">Nombre:</label>
                    <input type="text" id="new_client_name" name="new_client_name" placeholder="Nombre completo">
                    <label for="new_client_phone">Teléfono:</label>
                    <input type="text" id="new_client_phone" name="new_client_phone" placeholder="Teléfono del cliente">
                    <label for="new_client_location">Ubicación/Dirección:</label>
                    <input type="text" id="new_client_location" name="new_client_location" placeholder="Dirección de entrega">
                </div>
            </div>

            <ul id="current-order-list">
                <li id="empty-order-message" style="text-align: center; color: var(--dark-text);">No hay productos en el pedido.</li>
            </ul>
            <div id="current-order-total">Total: $0,00</div>
            <div class="order-buttons">
                <button class="clear" id="clear-order-btn">Limpiar Pedido</button>
                <button id="place-order-btn">Realizar Pedido</button>
            </div>
        </div>

        <div class="manage-orders-section">
            <h2>Gestionar Pedidos Existentes</h2>
            <?php if (!empty($pedidos_a_gestionar)): ?>
                <table class="order-table">
                    <thead>
                        <tr>
                            <th>ID Pedido</th>
                            <th>Cliente</th>
                            <th>Fecha</th>
                            <th>Total</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos_a_gestionar as $pedido): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($pedido['id']); ?></td>
                                <td>
                                    <?php
                                    if ($pedido['cliente_id'] !== null) {
                                        echo '<b>Registrado:</b><br>' . htmlspecialchars($pedido['cliente_email'] ?? 'N/A') . '<br>' . htmlspecialchars($pedido['cliente_nombre'] ?? 'N/A');
                                    } else {
                                        echo '<b>A la calle:</b><br>' . htmlspecialchars($pedido['nombre'] ?? 'N/A') . '<br>' . htmlspecialchars($pedido['ubicacion'] ?? 'N/A');
                                    }
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars(date('d/m/Y H:i', strtotime($pedido['fecha']))); ?></td>
                                <td>$<?php echo htmlspecialchars(number_format($pedido['total'], 2, ',', '.')); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo htmlspecialchars($pedido['estado']); ?>">
                                        <?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($pedido['estado']))); ?>
                                    </span>
                                </td>
                                <td class="order-actions">
                                    <select class="status-selector" data-order-id="<?php echo htmlspecialchars($pedido['id']); ?>">
                                        <option value="pendiente" <?php echo ($pedido['estado'] == 'pendiente') ? 'selected' : ''; ?>>Pendiente</option>
                                        <option value="en_preparacion" <?php echo ($pedido['estado'] == 'en_preparacion') ? 'selected' : ''; ?>>En Preparación</option>
                                        <option value="listo" <?php echo ($pedido['estado'] == 'listo') ? 'selected' : ''; ?>>Listo</option>
                                        <option value="entregado" <?php echo ($pedido['estado'] == 'entregado') ? 'selected' : ''; ?>>Entregado</option>
                                        <option value="cancelado" <?php echo ($pedido['estado'] == 'cancelado') ? 'selected' : ''; ?>>Cancelado</option>
                                    </select>
                                    <button class="update-status-btn" data-order-id="<?php echo htmlspecialchars($pedido['id']); ?>">Actualizar</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay pedidos registrados.</p>
            <?php endif; ?>
        </div>
    </div>

    <div class="logout-button-container">
        <a href="./../index.php?logout=true" class="logout-button">Cerrar Sesión</a>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const currentOrderList = document.getElementById('current-order-list');
        const currentOrderTotalDisplay = document.getElementById('current-order-total');
        const emptyOrderMessage = document.getElementById('empty-order-message');
        const placeOrderBtn = document.getElementById('place-order-btn');
        const clearOrderBtn = document.getElementById('clear-order-btn');
        const statusMessageDiv = document.getElementById('php-message');

        const existingClientIdSelect = document.getElementById('existing_cliente_id');
        const newClientFieldsDiv = document.getElementById('new-client-fields');
        const newClientNameInput = document.getElementById('new_client_name');
        const newClientPhoneInput = document.getElementById('new_client_phone');
        const newClientLocationInput = document.getElementById('new_client_location');

        let currentOrder = [];

        function showStatusMessage(message, type) {
            statusMessageDiv.textContent = message;
            statusMessageDiv.className = 'status-message ' + type;
            statusMessageDiv.style.display = 'block';
            setTimeout(() => {
                statusMessageDiv.style.display = 'none';
            }, 5000);
        }

        function updateOrderDisplay() {
            currentOrderList.innerHTML = '';
            let totalAmount = 0;
            if (currentOrder.length === 0) {
                currentOrderList.appendChild(emptyOrderMessage);
                emptyOrderMessage.style.display = 'block';
                placeOrderBtn.disabled = true;
                clearOrderBtn.disabled = true;
            } else {
                emptyOrderMessage.style.display = 'none';
                placeOrderBtn.disabled = false;
                clearOrderBtn.disabled = false;
                currentOrder.forEach((item, index) => {
                    const listItem = document.createElement('li');
                    const itemSubtotal = item.quantity * item.price;
                    totalAmount += itemSubtotal;
                    listItem.innerHTML = `
                        <span>${item.name} (x${item.quantity})</span>
                        <span>$${itemSubtotal.toFixed(2)}</span>
                        <button class="remove-item-btn" data-index="${index}" style="background: var(--error-color); color: white; border: none; cursor: pointer; border-radius: 50%; width: 20px; height: 20px; display: flex; justify-content: center; align-items: center; font-size: 0.8em;">X</button>
                    `;
                    currentOrderList.appendChild(listItem);
                });
            }
            currentOrderTotalDisplay.textContent = `Total: $${totalAmount.toFixed(2)}`;
        }

        existingClientIdSelect.addEventListener('change', function() {
            if (this.value === '0') {
                newClientFieldsDiv.style.display = 'block';
            } else {
                newClientFieldsDiv.style.display = 'none';
                newClientNameInput.value = '';
                newClientPhoneInput.value = '';
                newClientLocationInput.value = '';
            }
        });

        document.querySelectorAll('.add-to-order-btn').forEach(button => {
            button.addEventListener('click', function() {
                const productItem = this.closest('.product-item');
                const productId = productItem.querySelector('.product-name').dataset.id;
                const productName = productItem.querySelector('.product-name').textContent;
                const productPrice = parseFloat(productItem.querySelector('.product-price-value').textContent);
                const quantity = parseInt(productItem.querySelector('.quantity-input').value);
                if (isNaN(quantity) || quantity <= 0) { return; }
                const existingItem = currentOrder.find(item => item.id === productId);
                if (existingItem) {
                    existingItem.quantity += quantity;
                } else {
                    currentOrder.push({ id: productId, name: productName, price: productPrice, quantity: quantity });
                }
                updateOrderDisplay();
            });
        });

        currentOrderList.addEventListener('click', function(event) {
            if (event.target.classList.contains('remove-item-btn')) {
                currentOrder.splice(parseInt(event.target.dataset.index), 1);
                updateOrderDisplay();
            }
        });
placeOrderBtn.addEventListener('click', function() {
    const clienteId = parseInt(existingClientIdSelect.value);

    // Check if there are products in the order
    if (currentOrder.length === 0) {
        showStatusMessage('No hay productos para el pedido.', 'error');
        return;
    }

    // Create a new URLSearchParams object
    const params = new URLSearchParams();

    // Append the products_json string to the parameters
    params.append('productos_json', JSON.stringify(currentOrder.map(item => ({ producto_id: item.id, cantidad: item.quantity }))));
    params.append('place_order', '1');

    // Add customer data based on selection
    if (clienteId > 0) {
        params.append('cliente_id', clienteId);
    } else {
        if (newClientNameInput.value.trim() === '' || newClientPhoneInput.value.trim() === '' || newClientLocationInput.value.trim() === '') {
            showStatusMessage('Por favor, completa todos los campos del cliente no registrado.', 'error');
            return;
        }
        params.append('new_client_name', newClientNameInput.value.trim());
        params.append('new_client_phone', newClientPhoneInput.value.trim());
        params.append('new_client_location', newClientLocationInput.value.trim());
    }

    fetch('guardar_pedido.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: params // Pass the URLSearchParams object as the body
    })
    .then(response => response.json())
    .then(data => {
        showStatusMessage(data.message, data.success ? 'success' : 'error');
        if (data.success) {
            currentOrder = [];
            updateOrderDisplay();
            existingClientIdSelect.value = '0';
            newClientFieldsDiv.style.display = 'none';
            newClientNameInput.value = '';
            newClientPhoneInput.value = '';
            newClientLocationInput.value = '';
            setTimeout(() => location.reload(), 1500);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showStatusMessage('Error de conexión al guardar el pedido.', 'error');
    });
});
        placeOrderBtn.addEventListener('click', function() {
            const clienteId = parseInt(existingClientIdSelect.value);

            // Check if there are products in the order
            if (currentOrder.length === 0) {
                showStatusMessage('No hay productos para el pedido.', 'error');
                return;
            }

            // Create a new URLSearchParams object
            const params = new URLSearchParams();

            // Append the products_json string to the parameters
            params.append('productos_json', JSON.stringify(currentOrder.map(item => ({ producto_id: item.id, cantidad: item.quantity }))));
            params.append('place_order', '1');

            // Add customer data based on selection
            if (clienteId > 0) {
                params.append('cliente_id', clienteId);
            } else {
                if (newClientNameInput.value.trim() === '' || newClientPhoneInput.value.trim() === '' || newClientLocationInput.value.trim() === '') {
                    showStatusMessage('Por favor, completa todos los campos del cliente no registrado.', 'error');
                    return;
                }
                params.append('new_client_name', newClientNameInput.value.trim());
                params.append('new_client_phone', newClientPhoneInput.value.trim());
                params.append('new_client_location', newClientLocationInput.value.trim());
            }

            fetch('guardar_pedido.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: params // Pass the URLSearchParams object as the body
            })
            .then(response => response.json())
            .then(data => {
                showStatusMessage(data.message, data.success ? 'success' : 'error');
                if (data.success) {
                    currentOrder = [];
                    updateOrderDisplay();
                    existingClientIdSelect.value = '0';
                    newClientFieldsDiv.style.display = 'none';
                    newClientNameInput.value = '';
                    newClientPhoneInput.value = '';
                    newClientLocationInput.value = '';
                    setTimeout(() => location.reload(), 1500);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatusMessage('Error de conexión al guardar el pedido.', 'error');
            });
        });

        clearOrderBtn.addEventListener('click', () => {
             if (confirm('¿Limpiar el pedido actual?')) {
                currentOrder = [];
                updateOrderDisplay();
             }
        });

        document.querySelectorAll('.update-status-btn').forEach(button => {
            button.addEventListener('click', function() {
                const orderId = this.dataset.orderId;
                const newStatus = document.querySelector(`.status-selector[data-order-id="${orderId}"]`).value;
                if (!newStatus) return;

                if (confirm(`¿Cambiar estado del Pedido #${orderId} a "${newStatus}"?`)) {
                    fetch('update_order_status.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: new URLSearchParams({ order_id: orderId, new_status: newStatus })
                    })
                    .then(response => response.json())
                    .then(data => {
                        showStatusMessage(data.message, data.success ? 'success' : 'error');
                        if (data.success) {
                            setTimeout(() => location.reload(), 1500);
                        }
                    })
                    .catch(error => showStatusMessage('Error de conexión al actualizar el estado.', 'error'));
                }
            });
        });

        updateOrderDisplay(); // Initial call
    });
    </script>
    <div class="manage-orders-section">
    <h2>Gestionar Pedidos Existentes</h2>
    <?php if (!empty($pedidos_a_gestionar)): ?>
        <table class="order-table">
            <thead>
                </thead>
            <tbody>
                <?php foreach ($pedidos_a_gestionar as $pedido): ?>
                    <tr>
                        <td class="order-actions">
                            </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p>No hay pedidos registrados.</p>
    <?php endif; ?>
</div>
</body>
</html>