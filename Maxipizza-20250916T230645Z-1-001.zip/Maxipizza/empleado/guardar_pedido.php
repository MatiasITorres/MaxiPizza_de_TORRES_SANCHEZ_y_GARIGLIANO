<?php
session_start();
header('Content-Type: application/json');

// NOTA: Asegúrate de que esta ruta sea CORRECTA. Un error aquí es la causa más común de fallos.
require_once './../config.php';

$response = ['success' => false, 'message' => ''];

// Establecer la conexión a la base de datos
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    $response['message'] = 'Error de conexión con la base de datos: ' . $conn->connect_error;
    echo json_encode($response);
    exit();
}

// Redirigir si el usuario no está logeado o no es un empleado
if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'empleado') {
    $response['message'] = 'Acceso denegado.';
    echo json_encode($response);
    exit();
}

// Iniciar una transacción para asegurar la integridad de los datos
$conn->autocommit(false);

try {
    if (!isset($_POST['productos_json']) || empty($_POST['productos_json'])) {
        throw new Exception('No hay productos en el pedido.');
    }

    $productos_pedido = json_decode($_POST['productos_json'], true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Formato de productos JSON inválido: ' . json_last_error_msg());
    }

    $cliente_id = isset($_POST['cliente_id']) && $_POST['cliente_id'] !== '0' ? intval($_POST['cliente_id']) : NULL;
    $nombre_cliente_calle = $_POST['new_client_name'] ?? NULL;
    $ubicacion_cliente_calle = $_POST['new_client_location'] ?? NULL;
    $telefono_cliente_calle = $_POST['new_client_phone'] ?? NULL;

    // --- Lógica para crear un nuevo cliente si no está registrado ---
    if ($cliente_id === NULL) {
        if (empty($nombre_cliente_calle) || empty($ubicacion_cliente_calle) || empty($telefono_cliente_calle)) {
            throw new Exception('El nombre, teléfono y ubicación del cliente son obligatorios para clientes no registrados.');
        }

        // Generar un correo y contraseña temporales para clientes a la calle
        $email_temp = 'cliente_' . uniqid() . '@maxipizza.com';
        $password_temp = password_hash(uniqid(), PASSWORD_DEFAULT);

        $sql_insert_cliente = 'INSERT INTO clientes (nombre, email, telefono, ubicacion, password, rol) VALUES (?, ?, ?, ?, ?, "cliente")';
        $stmt_cliente = $conn->prepare($sql_insert_cliente);
        if (!$stmt_cliente) {
            throw new Exception('Error al preparar la consulta de cliente: ' . $conn->error);
        }
        $stmt_cliente->bind_param('sssss', $nombre_cliente_calle, $email_temp, $telefono_cliente_calle, $ubicacion_cliente_calle, $password_temp);
        if (!$stmt_cliente->execute()) {
            throw new Exception('Error al crear el nuevo cliente: ' . $stmt_cliente->error);
        }
        $cliente_id = $stmt_cliente->insert_id;
        $stmt_cliente->close();
    }

    // Calcular el total del pedido
    $total = 0;
    $stmt_productos = $conn->prepare('SELECT precio FROM productos WHERE id = ?');
    if (!$stmt_productos) {
        throw new Exception('Error al preparar la consulta de productos: ' . $conn->error);
    }

    foreach ($productos_pedido as $item) {
        $stmt_productos->bind_param('i', $item['producto_id']);
        $stmt_productos->execute();
        $result = $stmt_productos->get_result();
        if ($result->num_rows === 0) {
            throw new Exception('Producto no encontrado con ID: ' . $item['producto_id']);
        }
        $producto = $result->fetch_assoc();
        $total += $producto['precio'] * $item['cantidad'];
    }
    $stmt_productos->close();

    // Insertar el nuevo pedido en la tabla `pedidos`
    $sql_pedido = 'INSERT INTO pedidos (cliente_id, total) VALUES (?, ?)';
    $stmt_pedido = $conn->prepare($sql_pedido);
    if (!$stmt_pedido) {
        throw new Exception('Error al preparar la consulta de pedido: ' . $conn->error);
    }
    $stmt_pedido->bind_param('id', $cliente_id, $total);
    if (!$stmt_pedido->execute()) {
        throw new Exception('Error al ejecutar la consulta de pedido: ' . $stmt_pedido->error);
    }
    $pedido_id = $stmt_pedido->insert_id;
    $stmt_pedido->close();

    // Insertar los productos en la tabla `pedido_productos`
    $sql_pedido_productos = 'INSERT INTO pedido_productos (pedido_id, producto_id, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?)';
    $stmt_pedido_productos = $conn->prepare($sql_pedido_productos);
    if (!$stmt_pedido_productos) {
        throw new Exception('Error al preparar la consulta de pedido_productos: ' . $conn->error);
    }

    foreach ($productos_pedido as $item) {
        $stmt_productos_precio = $conn->prepare('SELECT precio FROM productos WHERE id = ?');
        $stmt_productos_precio->bind_param('i', $item['producto_id']);
        $stmt_productos_precio->execute();
        $producto = $stmt_productos_precio->get_result()->fetch_assoc();
        $precio_unitario = $producto['precio'];
        $subtotal = $precio_unitario * $item['cantidad'];
        $stmt_productos_precio->close();

        $stmt_pedido_productos->bind_param('iiidd', $pedido_id, $item['producto_id'], $item['cantidad'], $precio_unitario, $subtotal);
        if (!$stmt_pedido_productos->execute()) {
            throw new Exception('Error al agregar productos al pedido: ' . $stmt_pedido_productos->error);
        }
    }
    $stmt_pedido_productos->close();

    $conn->commit();
    $response['success'] = true;
    $response['message'] = 'Pedido creado con éxito. ID: ' . $pedido_id;

} catch (Exception $e) {
    $conn->rollback();
    $response['message'] = 'Error al crear el pedido: ' . $e->getMessage();
}

$conn->close();
echo json_encode($response);
?>