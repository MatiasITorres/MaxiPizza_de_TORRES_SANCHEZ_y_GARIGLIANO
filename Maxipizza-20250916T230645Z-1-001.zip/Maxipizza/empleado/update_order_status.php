<?php
session_start();
require_once './../config.php';

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Error de conexión: ' . $conn->connect_error]));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id']) && isset($_POST['new_status'])) {
    $order_id = (int)$_POST['order_id'];
    $new_status = $_POST['new_status'];

    // Validate allowed statuses to prevent SQL injection or invalid data
    $allowed_statuses = ['pendiente', 'en_preparacion', 'listo', 'entregado', 'cancelado'];
    if (!in_array($new_status, $allowed_statuses)) {
        echo json_encode(['success' => false, 'message' => 'Estado inválido.']);
        $conn->close();
        exit();
    }

    try {
        $stmt = $conn->prepare("UPDATE pedidos SET estado = ? WHERE id = ?");
        $stmt->bind_param("si", $new_status, $order_id);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true, 'message' => 'Estado del pedido actualizado con éxito.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No se encontró el pedido o el estado ya era el mismo.']);
        }
        $stmt->close();
    } catch (Exception $e) {
        error_log("Error al actualizar el estado del pedido: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Error al actualizar el estado: ' . $e->getMessage()]);
    }

    $conn->close();
} else {
    echo json_encode(['success' => false, 'message' => 'Solicitud inválida.']);
}
?>