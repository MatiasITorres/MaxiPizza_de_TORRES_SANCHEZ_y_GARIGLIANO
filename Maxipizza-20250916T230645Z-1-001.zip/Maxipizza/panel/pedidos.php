<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Conexión a la base de datos
$conexion = new mysqli("192.168.101.93", "AG08", "St2025#QUcwOA", "ag08");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'panel') {
    header("Location: ./../index.php");
    exit();
}

// Consulta todos los pedidos, sus productos y la información del cliente
$sql = "SELECT
            p.id,
            p.fecha,
            p.total,
            p.estado,
            c.nombre AS cliente,
            c.ubicacion AS direccion,
            c.telefono AS telefono,
            pr.nombre AS nombre_producto,
            pp.cantidad,
            pp.estado AS estado_producto
        FROM pedidos p
        LEFT JOIN clientes c ON p.cliente_id = c.id
        LEFT JOIN pedido_productos pp ON p.id = pp.pedido_id
        LEFT JOIN productos pr ON pp.producto_id = pr.id
        ORDER BY p.fecha DESC";

$resultado = $conexion->query($sql);

$pedidos = [];
if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        $pedido_id = $fila['id'];
        
        // Si el pedido no existe en nuestro array, lo inicializamos
        if (!isset($pedidos[$pedido_id])) {
            $pedidos[$pedido_id] = [
                'id' => $fila['id'],
                'fecha' => $fila['fecha'],
                'total' => $fila['total'],
                'estado' => $fila['estado'],
                'cliente' => $fila['cliente'],
                'direccion' => $fila['direccion'],
                'telefono' => $fila['telefono'],
                'productos' => []
            ];
        }

        // Agregamos el producto al pedido correspondiente
        if ($fila['nombre_producto'] !== null) {
            $pedidos[$pedido_id]['productos'][] = [
                'nombre' => $fila['nombre_producto'],
                'cantidad' => $fila['cantidad'],
                'estado' => $fila['estado_producto']
            ];
        }
    }
}

$pedidos_listos = [];
$pedidos_no_listos = [];

// Separar los pedidos en dos grupos, excluyendo los "entregados"
foreach ($pedidos as $pedido) {
    if ($pedido['estado'] == 'entregado') {
        // No hacer nada, simplemente ignoramos este pedido
        continue;
    }

    if ($pedido['estado'] == 'listo') {
        $pedidos_listos[] = $pedido;
    } else {
        $pedidos_no_listos[] = $pedido;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel de Pedidos | MaxiPizza</title>
    <link rel="stylesheet" href="./../css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600;700&family=Lobster&display=swap" rel="stylesheet">
    <style>
        /* Variables CSS (tomadas de admin_dashboard.php) */
        :root {
            --primary-color: #c0392b; /* Rojo pizza! */
            --secondary-color: #e67e22; /* Naranja vibrante (para encabezados) */
            --tertiary-color: #f39c12; /* Amarillo-naranja para modificar */
            --dark-text: #333; /* Texto oscuro */
            --light-bg: #f8f8f8; /* Fondo general claro */
            --white-bg: #ffffff;
            --light-border: #ddd; /* Bordes grises claros */
            --success-color: #27ae60;
            --error-color: #e74c3c;
            --info-color: #3498db;
            --grey-button: #7f8c8d; /* Gris para botones de cancelar/cerrar sesión */

            /* Estados de pedido */
            --status-pendiente: #f39c12; /* Amarillo-naranja para pendiente */
            --status-en_preparacion: #3498db; /* Azul para en preparación */
            --status-listo: #27ae60; /* Verde para listo */
            --status-entregado: #7f8c8d; /* Gris para entregado */
            --status-cancelado: #e74c3c; /* Rojo para cancelado */
        }

        body {
            font-family: 'Open Sans', sans-serif;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 25px;
            background-color: var(--light-bg);
            color: var(--dark-text);
            min-height: 100vh;
            align-items: center;
        }

        h1 {
            font-family: 'Lobster', cursive;
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 30px;
            font-size: 3em;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.1);
            padding-bottom: 10px;
            border-bottom: 2px solid var(--secondary-color);
            width: 100%;
            max-width: 1300px;
        }

        .dashboard-columns {
            display: flex;
            gap: 25px;
            width: 100%;
            max-width: 1300px;
            flex-wrap: wrap;
            justify-content: center;
        }

        .columna {
            flex: 1;
            min-width: 380px;
            background: var(--white-bg);
            padding: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
            border-radius: 10px;
            box-sizing: border-box;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-top: 20px;
            background: var(--white-bg);
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.05);
            border: 1px solid var(--light-border);
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--light-border);
            text-align: left;
            vertical-align: top;
            font-size: 1em;
        }
        th {
            background: var(--secondary-color);
            color: white;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f5f5f5;
        }
        h2 {
            font-family: 'Lobster', cursive;
            text-align: center;
            color: var(--primary-color);
            margin-bottom: 20px;
            font-size: 2em;
            border-bottom: 2px solid var(--light-border);
            padding-bottom: 10px;
            text-shadow: 1px 1px 3px rgba(0,0,0,0.08);
        }
        
        /* Status row styling */
        .estado-pendiente { background-color: #fff8e1; color: var(--dark-text); }
        .estado-en_preparacion { background-color: #e3f2fd; }
        .estado-listo { background-color: #e8f5e9; }
        .estado-entregado { background-color: #e0e0e0; }
        .estado-cancelado { background-color: #ffebee; color: var(--error-color); }
        
        /* Text for status inside table */
        .estado-text {
            font-weight: bold;
            display: inline-block;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9em;
            text-transform: capitalize;
            color: white;
        }
        .estado-text.pendiente { background-color: var(--status-pendiente); color: var(--dark-text); }
        .estado-text.en_preparacion { background-color: var(--status-en_preparacion); color: white; }
        .estado-text.listo { background-color: var(--status-listo); color: white; }
        .estado-text.entregado { background-color: var(--status-entregado); color: white; }
        .estado-text.cancelado { background-color: var(--status-cancelado); color: white; }

        .no-pedidos {
            text-align: center;
            padding: 30px 20px;
            background-color: #f0f0f0;
            border: 1px dashed #ccc;
            border-radius: 8px;
            color: #666;
            font-style: italic;
            margin-top: 20px;
        }
        .no-pedidos p {
            margin: 0;
            font-size: 1.1em;
        }

        .productos-lista {
            list-style: none;
            padding: 0;
            margin: 0;
            font-size: 0.9em;
        }

        /* Responsive adjustments */
        @media (max-width: 992px) {
            h1 { font-size: 2.5em; margin-bottom: 25px; }
            .dashboard-columns { flex-direction: column; align-items: center; gap: 20px; }
            .columna { min-width: unset; width: 95%; max-width: 600px; padding: 25px; }
            th, td { padding: 10px 12px; font-size: 0.95em; }
            h2 { font-size: 1.8em; margin-bottom: 15px; }
        }

        @media (max-width: 600px) {
            body { padding: 15px; gap: 20px; }
            h1 { font-size: 2em; margin-bottom: 20px; }
            .columna { padding: 20px; }
            th, td { padding: 8px 10px; font-size: 0.85em; }
            h2 { font-size: 1.5em; }
        }

        .back-button {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background-color: var(--secondary-color);
            color: white;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            transition: background-color 0.2s ease;
        }
        .back-button:hover {
            background-color: var(--tertiary-color);
        }
    </style>
</head>
<body>
    <h1>Panel General de Pedidos</h1>

    <div class="dashboard-columns">
        <div class="columna">
            <h2>Pedidos en Curso</h2>
            <?php if (count($pedidos_no_listos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>N° Pedido</th>
                            <th>Cliente</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos_no_listos as $p): ?>
                            <tr class="estado-<?php echo $p['estado']; ?>">
                                <td>
                                    <?php 
                                        $numero_pedido = ($p['id'] - 1) % 100 + 1;
                                        echo htmlspecialchars($numero_pedido);
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($p['cliente']); ?></td>
                                <td>
                                    <span class="estado-text <?php echo $p['estado']; ?>">
                                        <?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($p['estado']))); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-pedidos"><p>No hay pedidos pendientes o en preparación.</p></div>
            <?php endif; ?>
        </div>

        <div class="columna">
            <h2>Pedidos Listos</h2>
            <?php if (count($pedidos_listos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>N° Pedido</th>
                            <th>Cliente</th>
                            <th>Estado</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos_listos as $p): ?>
                            <tr class="estado-<?php echo $p['estado']; ?>">
                                <td>
                                    <?php 
                                        $numero_pedido = ($p['id'] + 1) % 100 + 1;
                                        echo htmlspecialchars($numero_pedido);
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($p['cliente']); ?></td>
                                <td>
                                    <span class="estado-text <?php echo $p['estado']; ?>">
                                        <?php echo htmlspecialchars(str_replace('_', ' ', ucfirst($p['estado']))); ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-pedidos"><p>No hay pedidos listos.</p></div>
            <?php endif; ?>
        </div>
    </div>
    <a href="./../empleado/empleado_dashboard.php" class="back-button">Volver al Panel</a>
</body>
</html>
<?php $conexion->close(); ?>