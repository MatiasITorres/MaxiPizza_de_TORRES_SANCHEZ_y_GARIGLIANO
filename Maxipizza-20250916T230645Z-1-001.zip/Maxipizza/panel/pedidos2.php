<?php
session_start();


$conexion = new mysqli("localhost", "root", "", "maxipizza");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

if (!isset($_SESSION['usuario_rol']) || $_SESSION['usuario_rol'] !== 'panel') {
    header("Location: ./../index.php");
    exit();
}

// Consulta todos los pedidos con numero_pedido
$sql = "SELECT
            p.numero_pedido,
            p.fecha,
            p.total,
            p.estado,
            COALESCE(c.nombre, p.nombre_cliente_calle) AS cliente,
            COALESCE(c.direccion, p.ubicacion_cliente_calle) AS direccion,
            COALESCE(c.telefono, p.telefono_cliente_calle) AS telefono
        FROM pedidos p
        LEFT JOIN clientes c ON p.cliente_id = c.id
        ORDER BY p.fecha DESC";

$resultado = $conexion->query($sql);

$pedidos_listos = [];
$pedidos_no_listos = [];

if ($resultado && $resultado->num_rows > 0) {
    while ($fila = $resultado->fetch_assoc()) {
        if (in_array($fila['estado'], ['listo', 'entregado'])) {
            $pedidos_listos[] = $fila;
        } else {
            $pedidos_no_listos[] = $fila;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Panel de Pedidos | MaxiPizza</title>
    <link rel="stylesheet" href="./../css/style.css">
    <!-- (Estilos omitidos aquí por brevedad, puedes conservar los tuyos) -->
</head>
<body>
    <h1>Panel General de Pedidos</h1>

    <div class="dashboard-columns">
        <div class="columna">
            <h2>Pedidos en Curso</h2>
            <?php if (count($pedidos_no_listos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nº Pedido</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos_no_listos as $p): ?>
                            <tr class="estado-<?php echo $p['estado']; ?>">
                                <td><?php echo htmlspecialchars($p['numero_pedido']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-pedidos"><p>No hay pedidos pendientes o en preparación.</p></div>
            <?php endif; ?>
        </div>

        <div class="columna">
            <h2>Pedidos Listos/Entregados</h2>
            <?php if (count($pedidos_listos) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nº Pedido</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pedidos_listos as $p): ?>
                            <tr class="estado-<?php echo $p['estado']; ?>">
                                <td><?php echo htmlspecialchars($p['numero_pedido']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-pedidos"><p>No hay pedidos listos o entregados.</p></div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
<?php $conexion->close(); ?>
